<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7cc9bed             |
    |_______________________________________|
*/
 pmpr_do_action("\x72\x65\x6e\x64\145\162\137\x63\x6f\155\x6d\x65\x6e\164\163");
