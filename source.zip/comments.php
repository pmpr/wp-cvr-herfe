<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c7a530dd4a             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
