<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e598cd16739             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
