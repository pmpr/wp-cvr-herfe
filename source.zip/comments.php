<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fd1398e792             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
