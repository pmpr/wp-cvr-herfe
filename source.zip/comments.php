<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14f830ccc             |
    |_______________________________________|
*/
 pmpr_do_action("\x72\145\x6e\x64\145\x72\x5f\143\x6f\x6d\x6d\x65\156\164\x73");
