<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85fee949             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\151\164\x5f\x63\x6f\166\x65\x72");
