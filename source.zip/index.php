<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7cc9bed             |
    |_______________________________________|
*/
 pmpr_do_action("\151\156\151\x74\x5f\x63\x6f\x76\x65\x72");
