<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7cc9bed             |
    |_______________________________________|
*/
 pmpr_do_action("\162\x65\x6e\x64\145\x72\x5f\x66\x6f\x6f\164\145\x72");
