<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d392069f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Breadcrumb extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('breadcrumb_generate_args', [$this, 'loyaoukiqyocgumm'])->aqaqisyssqeomwom('breadcrumb_allow_render', [$this, 'mguaggoqueykukka'], 99); } public function loyaoukiqyocgumm($ywmkwiwkosakssii = []) : array { return $this->caokeucsksukesyo()->gyecsegqciqykomu()->ckscqqquyskscaaw(['divider' => '/', 'wrap_attrs' => ['class' => 'px-0 py-3 m-0'], 'link_attrs' => ['class' => 'text-secondary-primary fs-xs font-weight-bold'], 'item_attrs' => ['class' => 'd-table-cell text-nowrap'], 'divider_attrs' => ['class' => 'mx-2 text-primary'], 'link_container' => null, 'active_item_attrs' => ['class' => 'active text-muted fs-xs d-table-cell text-nowrap']], $ywmkwiwkosakssii); } public function mguaggoqueykukka($gkuksucqwuewkwws) : bool { return $gkuksucqwuewkwws && !$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->takycgcamoacksqw(); } }
