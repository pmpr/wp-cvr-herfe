<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676e6b5393e5e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Herfe\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
