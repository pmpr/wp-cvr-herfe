<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fe217005             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\x74\151\x6e\x67\137\x66\x65\x65\144\x62\x61\143\x6b\x5f\146\157\x72\155\x5f\x66\151\x65\x6c\x64\163", [$this, "\x6d\145\x63\x67\141\141\143\171\x71\165\157\x75\x67\x75\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\141\151\156\x2d\x61\143\164\151\x6f\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\x65\x78\164\x2d\x6c\x65\x66\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\55\x77\x68\151\164\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x62\55\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
