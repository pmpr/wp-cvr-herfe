<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8c90ae16             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\164\151\156\147\137\146\145\145\x64\142\141\143\153\137\x66\157\x72\155\x5f\146\151\x65\154\x64\x73", [$this, "\155\145\x63\x67\141\x61\x63\x79\x71\165\x6f\165\147\x75\x65\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\141\x69\156\55\141\x63\x74\x69\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\170\x74\55\154\x65\146\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\x62\x67\55\x77\x68\151\x74\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\x62\55\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
