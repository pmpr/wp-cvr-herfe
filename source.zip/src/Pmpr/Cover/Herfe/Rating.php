<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e7d4d9094             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\x61\164\151\x6e\147\137\x66\x65\145\x64\x62\141\143\153\137\146\157\162\155\x5f\x66\x69\x65\x6c\x64\163", [$this, "\155\145\x63\147\141\141\x63\171\161\x75\x6f\x75\x67\x75\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\141\x69\x6e\x2d\141\143\x74\x69\x6f\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\145\170\164\x2d\x6c\145\x66\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\x2d\167\150\151\x74\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
