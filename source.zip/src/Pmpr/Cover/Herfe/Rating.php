<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723571f00508             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\164\151\156\147\137\x66\x65\145\144\x62\141\x63\153\x5f\x66\x6f\162\155\x5f\x66\151\145\154\144\163", [$this, "\x6d\x65\x63\x67\141\141\143\x79\161\x75\x6f\x75\147\x75\x65\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\141\151\156\55\141\143\x74\151\157\156")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\145\170\164\x2d\154\145\x66\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\55\x77\150\x69\x74\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\142\x2d\x35"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
