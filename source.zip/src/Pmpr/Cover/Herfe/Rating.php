<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357a92498e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\162\x61\x74\x69\x6e\147\x5f\146\x65\145\x64\142\141\143\x6b\x5f\x66\157\162\155\137\x66\151\x65\x6c\144\163", [$this, "\155\x65\x63\x67\141\141\x63\171\161\x75\x6f\x75\147\165\145\x67"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x61\151\156\x2d\x61\x63\164\x69\x6f\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\164\x65\x78\x74\55\154\145\x66\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\x67\x2d\x77\x68\x69\x74\145"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x62\55\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
