<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e6c2d939a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\x61\x74\151\156\147\x5f\x66\145\145\x64\142\x61\143\153\x5f\x66\157\x72\x6d\137\146\151\145\154\x64\163", [$this, "\x6d\145\x63\x67\141\x61\x63\x79\x71\165\157\165\x67\165\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\141\151\156\x2d\x61\143\164\x69\157\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\x78\164\55\154\x65\146\x74"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\x2d\167\x68\151\164\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\x6d\142\x2d\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
