<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e4220edb3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Field; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom("\x72\x61\x74\x69\156\147\137\x66\145\145\144\142\141\x63\x6b\137\146\157\162\x6d\x5f\x66\x69\x65\x6c\x64\163", [$this, "\155\x65\143\x67\x61\141\x63\x79\161\165\x6f\x75\x67\x75\145\147"]); } public function mecgaacyquougueg(array $ikgwqyuyckaewsow = []) : array { foreach ($ikgwqyuyckaewsow as $momcykaoccoymeig => $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Field) { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->qigsyyqgewgskemg("\155\141\151\x6e\x2d\141\143\x74\x69\157\x6e")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x74\145\170\164\55\x6c\x65\146\164"); } else { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->macygmcekgqwmcwk()->qigsyyqgewgskemg("\142\147\x2d\167\x68\x69\x74\x65"); } $aiowsaccomcoikus->qigsyyqgewgskemg("\155\x62\x2d\65"); } } $ikgwqyuyckaewsow[$momcykaoccoymeig] = $aiowsaccomcoikus; } return $ikgwqyuyckaewsow; } }
