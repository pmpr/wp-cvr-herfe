<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66334148299b7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component\Module; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
