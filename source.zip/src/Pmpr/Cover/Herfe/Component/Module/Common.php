<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009332786             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component\Module; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
