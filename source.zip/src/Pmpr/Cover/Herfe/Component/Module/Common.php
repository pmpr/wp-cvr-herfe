<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf7810605b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component\Module; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
