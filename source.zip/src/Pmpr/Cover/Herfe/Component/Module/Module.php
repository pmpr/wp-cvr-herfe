<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce76464df21             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component\Module; class Module extends Common { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
