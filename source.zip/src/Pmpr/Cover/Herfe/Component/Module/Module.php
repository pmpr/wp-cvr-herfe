<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e51c407b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component\Module; class Module extends Common { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
