<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4e90307a77             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component; use Pmpr\Cover\Herfe\Component\Module\Module; use Pmpr\Cover\Herfe\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
