<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a88ee998             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Component; use Pmpr\Cover\Herfe\Component\Module\Module; use Pmpr\Cover\Herfe\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
