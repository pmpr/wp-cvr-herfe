<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf7810605b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\x6e\x79\x5f\155\x63\145\x5f\x62\x65\146\x6f\x72\145\x5f\151\x6e\x69\164", [$this, "\141\143\x61\165\167\x65\x71\x79\x79\x75\x67\x77\x69\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\x5f\142\165\x74\x74\157\156\163", [$this, "\x61\163\x61\161\145\147\145\x77\165\x69\x71\145\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\164\163\x69\172\x65\x73\145\x6c\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\x6e\x74\x73\151\x7a\x65\137\146\157\162\x6d\141\x74\x73"] = "\x38\x70\x78\x20\61\x30\x70\170\40\61\x32\160\170\40\x31\x34\x70\x78\40\x31\x36\x70\170\x20\62\x30\160\170\40\x32\x34\x70\170\40\x32\x38\x70\170\40\x33\62\160\170\x20\63\66\x70\170\x20\x34\70\x70\x78\40\66\x30\160\170\x20\x37\x32\x70\170\x20\71\66\160\170"; return $iwsskoiwswyqeuee; } }
