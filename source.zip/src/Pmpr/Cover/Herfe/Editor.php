<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c4e0a51c795             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\x6e\x79\x5f\x6d\x63\x65\x5f\142\145\x66\157\x72\145\x5f\151\x6e\151\x74", [$this, "\x61\x63\141\165\167\x65\161\x79\x79\x75\x67\x77\x69\x73\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\145\137\142\x75\164\164\157\156\163", [$this, "\141\163\x61\x71\x65\147\x65\x77\165\151\x71\145\x65\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\x6e\164\163\151\172\145\x73\x65\x6c\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\156\164\163\x69\x7a\145\x5f\146\157\162\155\x61\x74\163"] = "\70\160\170\x20\x31\x30\x70\x78\40\x31\x32\160\x78\40\61\x34\x70\x78\40\x31\66\x70\x78\x20\62\60\160\170\40\x32\x34\160\x78\40\62\x38\160\170\40\63\x32\160\170\x20\x33\66\160\x78\x20\x34\x38\x70\x78\x20\66\x30\160\x78\40\x37\x32\160\x78\40\x39\66\160\170"; return $iwsskoiwswyqeuee; } }
