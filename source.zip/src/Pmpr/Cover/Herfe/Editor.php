<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646ac739e06d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\x6e\171\137\x6d\x63\x65\x5f\142\x65\x66\x6f\x72\x65\137\151\156\151\x74", [$this, "\141\x63\141\165\167\145\161\x79\x79\165\147\167\x69\163\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\137\142\165\164\164\157\x6e\x73", [$this, "\x61\x73\141\x71\145\x67\x65\167\x75\151\161\x65\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\164\163\151\x7a\x65\163\145\x6c\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\164\x73\x69\172\x65\x5f\146\x6f\162\155\141\x74\163"] = "\x38\160\170\40\61\x30\160\170\40\61\x32\x70\x78\40\61\64\160\170\x20\x31\x36\160\x78\x20\x32\60\160\x78\x20\62\64\x70\170\x20\62\x38\x70\x78\x20\63\62\160\x78\x20\63\x36\x70\170\x20\x34\x38\160\x78\40\66\60\160\x78\x20\x37\62\x70\x78\40\x39\x36\x70\x78"; return $iwsskoiwswyqeuee; } }
