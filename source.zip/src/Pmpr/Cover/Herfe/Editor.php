<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114f15b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\156\x79\x5f\155\143\x65\137\142\x65\146\157\x72\145\x5f\151\156\x69\164", [$this, "\141\x63\x61\165\167\145\x71\x79\x79\x75\x67\x77\x69\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\x5f\142\165\164\x74\x6f\156\x73", [$this, "\x61\163\x61\x71\145\147\x65\x77\165\151\161\x65\x65\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\x74\163\x69\x7a\145\163\145\154\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\x74\x73\151\172\145\x5f\146\x6f\162\155\x61\164\163"] = "\70\x70\x78\x20\x31\60\x70\x78\x20\61\62\160\170\x20\61\64\160\170\x20\x31\66\160\170\40\x32\60\x70\x78\x20\62\x34\160\170\40\62\x38\x70\x78\40\63\x32\160\170\40\x33\x36\x70\x78\40\x34\70\160\x78\x20\x36\x30\160\170\x20\x37\x32\x70\170\x20\x39\x36\x70\x78"; return $iwsskoiwswyqeuee; } }
