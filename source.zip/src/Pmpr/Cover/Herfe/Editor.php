<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85fee949             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\156\171\137\155\x63\x65\137\x62\x65\x66\157\162\x65\x5f\x69\x6e\151\x74", [$this, "\141\143\x61\x75\167\145\161\171\171\x75\x67\x77\151\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\x5f\x62\165\164\x74\x6f\156\x73", [$this, "\x61\x73\x61\x71\145\147\145\167\x75\151\161\145\x65\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\x6e\x74\163\x69\172\145\x73\145\x6c\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\156\164\x73\151\172\145\x5f\x66\x6f\x72\x6d\141\164\163"] = "\x38\160\x78\40\61\60\x70\170\40\61\62\160\x78\x20\x31\64\160\x78\40\x31\x36\160\x78\40\62\x30\160\170\x20\x32\x34\160\170\x20\x32\70\x70\170\40\x33\62\160\170\x20\63\66\x70\x78\40\64\70\160\x78\40\x36\x30\160\x78\x20\67\62\160\x78\x20\x39\x36\160\170"; return $iwsskoiwswyqeuee; } }
