<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707ca1bba4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\x79\137\x6d\x63\145\137\142\x65\146\157\162\x65\x5f\151\156\151\x74", [$this, "\x61\x63\141\165\x77\145\x71\171\171\165\147\x77\151\163\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\137\142\165\164\x74\157\x6e\x73", [$this, "\x61\x73\x61\161\x65\147\x65\167\165\x69\161\x65\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\x74\163\151\x7a\x65\163\145\154\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\156\164\x73\x69\x7a\145\x5f\x66\x6f\x72\x6d\x61\x74\163"] = "\70\160\x78\40\61\x30\x70\170\x20\61\x32\160\170\x20\x31\x34\160\170\40\x31\66\x70\x78\x20\62\60\x70\x78\40\x32\x34\x70\170\40\62\x38\160\170\40\63\x32\160\170\40\x33\66\x70\170\40\64\70\x70\x78\x20\x36\x30\x70\170\40\x37\62\160\170\x20\x39\x36\160\170"; return $iwsskoiwswyqeuee; } }
