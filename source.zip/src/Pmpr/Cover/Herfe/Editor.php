<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce76464df21             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\x6e\171\137\x6d\x63\x65\137\x62\145\x66\x6f\x72\x65\137\x69\156\151\x74", [$this, "\141\x63\141\x75\167\145\x71\171\171\165\147\x77\151\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\x5f\142\x75\164\164\157\x6e\x73", [$this, "\x61\x73\x61\161\x65\x67\145\x77\165\151\161\x65\x65\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\164\x73\x69\x7a\145\163\145\x6c\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\156\164\x73\151\172\x65\137\x66\157\x72\155\141\164\163"] = "\x38\x70\170\40\x31\60\x70\170\x20\x31\x32\x70\x78\x20\61\64\x70\170\40\x31\66\x70\x78\x20\x32\60\160\170\40\x32\64\160\170\40\62\x38\x70\x78\40\63\x32\x70\170\x20\63\x36\x70\x78\40\x34\70\160\x78\x20\x36\x30\160\x78\x20\67\x32\160\x78\40\71\66\x70\x78"; return $iwsskoiwswyqeuee; } }
