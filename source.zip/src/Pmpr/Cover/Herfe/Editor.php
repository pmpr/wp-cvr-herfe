<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009332786             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\x6e\x79\137\155\143\145\137\142\x65\x66\x6f\162\145\137\x69\x6e\x69\x74", [$this, "\141\143\x61\165\167\x65\161\x79\x79\165\147\x77\x69\163\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\x5f\x62\x75\164\164\x6f\x6e\163", [$this, "\x61\x73\x61\161\x65\147\145\167\165\151\161\145\145\143\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\164\x73\x69\172\145\163\145\154\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\x73\x69\172\145\137\x66\157\x72\x6d\x61\x74\x73"] = "\x38\x70\x78\40\61\60\x70\170\40\61\x32\x70\170\x20\x31\x34\160\x78\x20\x31\66\160\170\40\62\60\160\x78\40\62\x34\x70\170\40\62\x38\x70\x78\40\x33\x32\160\170\x20\63\x36\x70\170\x20\64\70\x70\170\x20\x36\60\x70\170\x20\x37\x32\160\x78\x20\x39\x36\160\170"; return $iwsskoiwswyqeuee; } }
