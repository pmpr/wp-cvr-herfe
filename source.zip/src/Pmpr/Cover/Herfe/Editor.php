<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1bfa0a1e1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\x6e\x79\x5f\155\143\x65\x5f\x62\145\x66\157\x72\x65\137\151\x6e\151\x74", [$this, "\141\143\141\165\x77\x65\x71\x79\x79\x75\147\167\151\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\137\x62\x75\x74\x74\x6f\156\163", [$this, "\141\163\x61\x71\x65\147\x65\167\x75\151\161\145\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\x6e\x74\163\x69\x7a\x65\x73\x65\x6c\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\164\x73\151\x7a\145\x5f\x66\x6f\162\155\141\x74\163"] = "\70\160\170\40\x31\x30\x70\x78\40\x31\x32\160\170\x20\61\64\x70\x78\x20\61\66\x70\170\40\x32\60\160\170\x20\x32\x34\160\x78\40\x32\70\160\x78\x20\63\x32\160\170\40\x33\66\x70\x78\40\64\70\x70\x78\x20\66\60\160\170\40\x37\x32\160\170\40\x39\x36\x70\170"; return $iwsskoiwswyqeuee; } }
