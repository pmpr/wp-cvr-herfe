<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66812ea1dcd5a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\171\137\x6d\143\x65\137\142\145\x66\x6f\162\145\137\x69\156\151\164", [$this, "\141\143\141\165\x77\x65\161\171\171\x75\x67\167\151\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\x5f\142\165\164\164\x6f\x6e\x73", [$this, "\141\163\x61\161\145\147\x65\167\165\x69\x71\145\145\143\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\164\x73\x69\x7a\145\x73\x65\x6c\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\x74\x73\x69\172\145\x5f\x66\157\162\155\x61\164\163"] = "\70\x70\170\40\x31\60\160\x78\x20\61\x32\160\x78\40\x31\x34\x70\x78\40\61\66\160\170\40\62\60\x70\170\40\x32\64\160\x78\x20\x32\70\x70\170\x20\63\x32\160\170\x20\x33\x36\160\x78\40\64\70\x70\170\40\x36\60\x70\170\x20\67\62\160\170\x20\x39\x36\x70\x78"; return $iwsskoiwswyqeuee; } }
