<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a4a550025             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\x79\137\155\x63\x65\137\x62\x65\x66\157\162\145\137\x69\156\x69\164", [$this, "\x61\x63\141\x75\167\x65\161\171\171\x75\x67\x77\x69\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\145\x5f\142\165\164\x74\157\x6e\163", [$this, "\x61\x73\141\x71\x65\x67\145\x77\165\151\x71\145\x65\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\156\x74\x73\x69\172\x65\x73\145\x6c\x65\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\x73\x69\x7a\145\137\146\x6f\162\155\141\164\163"] = "\70\160\170\x20\61\60\x70\x78\40\61\62\160\x78\40\x31\64\160\x78\x20\61\x36\x70\x78\40\62\x30\x70\170\x20\x32\64\x70\x78\40\62\70\x70\x78\40\x33\62\160\x78\x20\63\66\160\170\x20\x34\x38\160\x78\40\66\x30\160\x78\x20\x37\x32\160\x78\40\x39\66\160\x78"; return $iwsskoiwswyqeuee; } }
