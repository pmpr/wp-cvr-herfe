<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d60c76657e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\171\x5f\155\143\145\137\142\x65\146\157\162\145\137\151\x6e\151\164", [$this, "\x61\x63\141\x75\x77\145\161\171\171\x75\147\x77\151\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\137\x62\x75\164\x74\157\x6e\x73", [$this, "\141\x73\x61\161\x65\147\x65\167\x75\x69\161\x65\145\143\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\156\164\x73\151\x7a\145\163\x65\154\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\x74\x73\151\x7a\145\x5f\146\x6f\x72\155\x61\164\x73"] = "\70\x70\170\x20\x31\60\160\x78\x20\61\62\160\170\40\x31\x34\x70\170\x20\x31\x36\160\x78\x20\x32\x30\x70\170\x20\62\64\x70\x78\40\x32\x38\160\x78\x20\x33\x32\160\170\40\63\x36\160\x78\40\64\x38\160\170\40\x36\60\x70\x78\x20\x37\x32\x70\170\40\x39\66\x70\170"; return $iwsskoiwswyqeuee; } }
