<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66334148299b7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\x79\x5f\x6d\x63\x65\137\142\145\x66\157\x72\x65\137\x69\x6e\x69\x74", [$this, "\x61\143\x61\x75\167\x65\161\171\171\165\147\167\x69\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\x5f\142\x75\x74\x74\x6f\x6e\x73", [$this, "\x61\x73\141\161\145\147\x65\x77\x75\151\x71\x65\x65\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\x74\x73\x69\172\x65\163\145\154\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\x74\x73\151\172\145\x5f\x66\x6f\162\x6d\x61\x74\x73"] = "\70\160\170\40\61\60\x70\x78\40\x31\x32\160\x78\x20\x31\64\x70\170\40\x31\x36\160\170\40\x32\60\x70\x78\40\x32\64\x70\x78\40\62\x38\160\x78\40\63\x32\160\x78\40\63\x36\160\x78\x20\x34\x38\x70\x78\40\x36\x30\160\x78\x20\x37\62\160\x78\x20\x39\66\x70\170"; return $iwsskoiwswyqeuee; } }
