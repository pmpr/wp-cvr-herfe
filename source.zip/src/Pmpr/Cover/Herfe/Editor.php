<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8c90ae16             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\x6e\171\137\x6d\143\x65\137\x62\x65\146\157\x72\145\137\x69\156\x69\x74", [$this, "\141\143\x61\x75\167\145\x71\x79\171\165\x67\x77\x69\x73\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\137\142\165\x74\x74\x6f\x6e\163", [$this, "\x61\163\141\161\x65\x67\145\x77\x75\x69\161\x65\145\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\x6e\x74\163\x69\x7a\145\x73\x65\154\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\156\164\163\151\x7a\145\137\146\157\x72\155\x61\x74\x73"] = "\70\x70\x78\40\x31\x30\160\x78\40\x31\x32\160\x78\x20\61\x34\x70\x78\x20\x31\66\x70\x78\x20\x32\x30\x70\170\x20\62\64\x70\x78\40\x32\x38\160\x78\x20\63\x32\x70\x78\x20\x33\x36\x70\170\40\64\70\x70\x78\40\66\60\160\170\40\67\62\x70\x78\x20\71\66\160\170"; return $iwsskoiwswyqeuee; } }
