<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe1a193c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\171\137\x6d\x63\145\137\142\x65\146\x6f\x72\x65\x5f\x69\x6e\151\x74", [$this, "\x61\x63\x61\165\167\145\x71\x79\x79\x75\x67\x77\x69\x73\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\x65\x5f\142\165\x74\164\x6f\156\x73", [$this, "\x61\163\x61\x71\145\x67\145\x77\165\151\x71\145\145\143\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\164\x73\151\x7a\x65\x73\145\x6c\x65\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\x73\151\x7a\145\x5f\146\157\x72\155\x61\164\163"] = "\70\160\x78\x20\x31\x30\x70\x78\x20\x31\62\160\170\40\61\x34\x70\x78\x20\x31\x36\x70\170\40\x32\60\x70\170\40\62\64\160\x78\x20\62\70\160\x78\40\63\62\160\170\40\x33\66\160\170\40\64\70\160\170\x20\66\60\x70\x78\x20\67\62\160\x78\x20\x39\x36\160\x78"; return $iwsskoiwswyqeuee; } }
