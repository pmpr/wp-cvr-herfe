<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357a92498e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\156\171\x5f\155\143\145\x5f\142\145\146\x6f\x72\x65\x5f\151\x6e\x69\164", [$this, "\x61\143\x61\x75\x77\145\161\x79\x79\165\x67\167\151\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\x65\x5f\142\165\164\164\157\x6e\x73", [$this, "\x61\x73\x61\x71\x65\x67\145\167\x75\151\x71\x65\145\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\x74\x73\151\172\x65\x73\145\154\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\164\163\151\x7a\x65\x5f\146\157\162\x6d\141\164\163"] = "\x38\x70\170\x20\x31\x30\x70\x78\40\x31\x32\160\170\x20\x31\64\160\x78\x20\x31\x36\x70\x78\x20\62\60\x70\170\40\x32\64\x70\x78\x20\62\x38\x70\x78\40\x33\x32\160\170\40\x33\66\x70\x78\40\x34\x38\160\170\40\x36\x30\160\170\40\x37\x32\x70\x78\x20\71\66\x70\170"; return $iwsskoiwswyqeuee; } }
