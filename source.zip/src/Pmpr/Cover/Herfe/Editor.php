<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14f830ccc             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\x6e\x79\137\x6d\x63\x65\137\142\145\x66\157\162\x65\137\x69\156\x69\x74", [$this, "\x61\x63\x61\x75\167\145\x71\x79\x79\165\x67\x77\151\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\137\x62\x75\164\164\157\x6e\163", [$this, "\141\163\x61\x71\x65\147\x65\167\x75\x69\x71\145\145\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\156\x74\x73\151\x7a\x65\163\145\154\x65\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\163\x69\x7a\145\x5f\146\157\x72\x6d\x61\164\x73"] = "\x38\x70\170\40\x31\60\160\x78\40\61\62\x70\x78\x20\x31\64\160\x78\x20\x31\x36\x70\170\40\62\x30\x70\170\40\x32\x34\x70\170\40\62\70\x70\x78\x20\x33\x32\160\170\x20\63\66\160\x78\x20\64\70\x70\170\40\66\x30\x70\x78\40\x37\x32\160\170\40\71\66\160\170"; return $iwsskoiwswyqeuee; } }
