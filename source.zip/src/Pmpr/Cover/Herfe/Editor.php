<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7cc9bed             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\x6e\171\137\x6d\143\145\x5f\x62\145\146\x6f\x72\145\137\x69\x6e\x69\164", [$this, "\x61\143\141\x75\167\145\x71\x79\x79\165\x67\x77\x69\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\137\142\165\x74\164\157\x6e\x73", [$this, "\x61\163\x61\161\x65\x67\145\167\x75\151\161\145\x65\x63\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\x74\163\151\172\145\163\145\x6c\x65\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\x74\163\x69\x7a\x65\137\x66\x6f\x72\x6d\x61\x74\x73"] = "\x38\160\170\40\x31\x30\160\170\x20\61\x32\x70\170\x20\x31\64\x70\x78\40\61\66\160\x78\40\62\x30\160\x78\40\x32\64\x70\170\40\62\70\x70\x78\x20\x33\62\160\170\40\x33\x36\x70\170\40\64\x38\x70\170\40\66\x30\160\170\x20\67\x32\x70\170\x20\x39\66\x70\x78"; return $iwsskoiwswyqeuee; } }
