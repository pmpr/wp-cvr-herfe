<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a819971             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\156\171\x5f\x6d\x63\x65\x5f\x62\145\146\157\162\x65\x5f\151\x6e\x69\x74", [$this, "\x61\143\x61\x75\x77\145\161\171\171\165\x67\x77\151\163\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\137\x62\165\164\x74\x6f\156\163", [$this, "\141\x73\141\x71\x65\x67\x65\x77\165\151\161\x65\145\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\156\x74\x73\x69\x7a\145\x73\145\x6c\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\x73\x69\172\x65\137\x66\157\x72\155\141\164\x73"] = "\x38\160\x78\40\x31\x30\160\170\40\61\62\160\x78\40\x31\64\160\170\40\61\x36\x70\x78\40\x32\60\x70\x78\x20\x32\64\x70\170\40\x32\x38\x70\170\40\x33\x32\x70\x78\x20\x33\66\160\x78\40\64\x38\x70\x78\40\x36\x30\160\170\x20\67\x32\160\170\40\x39\66\160\x78"; return $iwsskoiwswyqeuee; } }
