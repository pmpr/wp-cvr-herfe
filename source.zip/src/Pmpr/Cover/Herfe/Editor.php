<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723571f00508             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\171\x5f\x6d\143\145\137\142\x65\x66\x6f\x72\145\x5f\151\156\151\x74", [$this, "\141\143\141\x75\167\145\x71\x79\171\165\147\167\151\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\x5f\142\x75\164\164\x6f\156\x73", [$this, "\x61\x73\x61\161\145\x67\145\167\x75\x69\x71\x65\145\143\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\164\x73\x69\172\145\163\145\x6c\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\x74\x73\151\x7a\x65\x5f\146\157\x72\155\141\x74\x73"] = "\x38\x70\170\40\61\x30\160\x78\40\x31\62\x70\170\x20\x31\64\160\x78\x20\x31\x36\160\x78\x20\x32\x30\x70\x78\40\x32\64\160\x78\x20\62\70\x70\170\x20\63\x32\160\x78\40\63\66\160\170\x20\64\x38\160\170\40\x36\x30\160\x78\40\67\62\160\170\40\x39\x36\x70\x78"; return $iwsskoiwswyqeuee; } }
