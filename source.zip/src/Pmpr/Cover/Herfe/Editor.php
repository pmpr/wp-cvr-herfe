<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66473510dd986             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\171\137\155\x63\x65\x5f\x62\x65\x66\x6f\x72\145\137\x69\x6e\151\x74", [$this, "\141\143\x61\165\x77\x65\x71\171\x79\x75\x67\x77\x69\163\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\137\x62\x75\x74\164\x6f\x6e\x73", [$this, "\x61\x73\x61\161\145\147\x65\x77\x75\x69\161\145\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\156\164\163\151\172\145\163\145\x6c\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\x74\x73\151\172\145\137\146\x6f\x72\x6d\141\x74\163"] = "\x38\160\x78\40\61\x30\160\x78\40\61\62\x70\170\40\61\64\160\170\x20\x31\x36\x70\x78\x20\x32\60\160\170\x20\x32\64\160\170\x20\x32\70\160\x78\x20\x33\62\x70\x78\x20\63\x36\160\x78\40\64\70\160\x78\x20\66\x30\x70\x78\x20\x37\62\x70\170\40\71\x36\160\x78"; return $iwsskoiwswyqeuee; } }
