<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1d9a7114f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\x6e\171\137\155\x63\145\x5f\x62\145\x66\157\x72\145\137\x69\156\x69\x74", [$this, "\141\x63\x61\x75\167\145\x71\x79\x79\165\x67\167\x69\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\x63\x65\x5f\142\165\164\164\x6f\x6e\x73", [$this, "\x61\163\141\161\x65\x67\x65\167\165\x69\x71\145\145\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\156\164\163\151\x7a\145\x73\x65\154\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\x74\163\151\172\145\x5f\x66\x6f\x72\x6d\x61\x74\163"] = "\70\x70\170\x20\x31\60\160\x78\x20\61\x32\x70\x78\x20\61\x34\160\x78\40\61\66\160\170\x20\62\x30\x70\170\40\x32\x34\x70\x78\x20\x32\70\x70\x78\40\63\62\x70\x78\x20\63\66\x70\170\x20\x34\70\160\x78\x20\66\x30\x70\170\40\x37\62\x70\170\x20\71\66\160\170"; return $iwsskoiwswyqeuee; } }
