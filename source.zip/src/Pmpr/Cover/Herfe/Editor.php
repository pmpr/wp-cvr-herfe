<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b6239b5da             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\156\x79\x5f\155\x63\x65\x5f\142\145\x66\157\x72\x65\137\x69\156\x69\164", [$this, "\141\143\x61\x75\x77\x65\161\x79\171\x75\147\167\x69\x73\x71\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\145\137\142\x75\164\x74\157\x6e\163", [$this, "\x61\x73\x61\161\x65\147\x65\167\x75\x69\x71\x65\145\x63\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\156\x74\163\151\172\145\x73\x65\154\145\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\164\163\x69\172\145\137\x66\x6f\x72\x6d\x61\164\x73"] = "\x38\x70\170\40\61\60\160\x78\x20\61\x32\160\170\x20\x31\x34\x70\x78\x20\61\x36\160\x78\x20\62\x30\x70\170\x20\62\x34\160\x78\40\x32\70\160\170\x20\63\x32\160\x78\x20\x33\66\160\x78\x20\64\x38\160\170\x20\x36\x30\160\170\x20\x37\62\160\x78\x20\x39\66\160\170"; return $iwsskoiwswyqeuee; } }
