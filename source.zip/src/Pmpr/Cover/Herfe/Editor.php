<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e4220edb3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\156\171\137\x6d\x63\145\137\142\x65\x66\157\162\145\137\x69\x6e\x69\x74", [$this, "\x61\x63\141\165\167\145\x71\x79\171\165\147\x77\151\163\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\x5f\142\x75\164\164\x6f\156\163", [$this, "\141\163\141\x71\145\x67\x65\x77\165\151\x71\x65\x65\143\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\x6e\x74\163\151\x7a\145\x73\x65\x6c\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\x6e\164\x73\151\x7a\x65\137\146\x6f\162\155\x61\x74\x73"] = "\x38\160\x78\x20\x31\x30\160\x78\40\61\62\x70\170\40\61\64\160\170\x20\61\66\160\170\x20\x32\60\x70\x78\x20\x32\64\x70\170\x20\62\x38\x70\x78\x20\x33\62\x70\170\x20\63\66\x70\x78\40\x34\x38\x70\170\x20\x36\60\160\170\40\x37\62\x70\170\x20\71\66\x70\170"; return $iwsskoiwswyqeuee; } }
