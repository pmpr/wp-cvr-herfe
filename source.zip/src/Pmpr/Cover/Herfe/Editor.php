<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a88ee998             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\156\x79\x5f\155\x63\x65\137\142\x65\x66\x6f\x72\145\x5f\151\x6e\x69\164", [$this, "\141\143\x61\165\x77\145\x71\x79\171\165\x67\167\151\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\x5f\x62\x75\x74\x74\157\x6e\163", [$this, "\x61\163\141\161\x65\x67\145\x77\x75\151\x71\145\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\x74\163\x69\x7a\x65\163\145\154\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\x6e\x74\163\x69\172\x65\x5f\x66\x6f\x72\x6d\141\164\163"] = "\x38\160\170\x20\x31\x30\160\x78\x20\61\x32\160\170\40\x31\64\160\170\x20\x31\x36\160\170\x20\x32\x30\160\x78\x20\62\64\160\x78\x20\62\x38\x70\x78\40\x33\62\160\x78\40\63\66\x70\170\40\x34\70\160\170\40\66\x30\x70\170\x20\67\62\x70\170\x20\x39\66\160\x78"; return $iwsskoiwswyqeuee; } }
