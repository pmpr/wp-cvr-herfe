<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e6c2d939a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\171\137\x6d\143\x65\137\142\x65\x66\x6f\x72\145\x5f\151\156\151\164", [$this, "\141\143\141\x75\167\x65\161\171\171\165\147\x77\x69\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\137\x62\x75\x74\164\157\156\x73", [$this, "\141\x73\x61\x71\x65\147\145\167\165\x69\161\145\x65\x63\x75\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\x6e\x74\163\151\x7a\145\163\145\154\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\x74\x73\x69\x7a\145\x5f\x66\x6f\162\155\x61\x74\163"] = "\70\x70\x78\x20\61\60\x70\x78\40\61\62\160\x78\40\x31\64\x70\170\40\61\66\x70\170\x20\62\60\x70\170\x20\x32\x34\x70\x78\40\62\x38\160\170\x20\63\x32\x70\170\x20\63\66\x70\170\x20\64\70\160\170\40\x36\60\x70\170\40\x37\62\160\x78\40\x39\x36\x70\170"; return $iwsskoiwswyqeuee; } }
