<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fe217005             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\156\171\137\x6d\x63\x65\137\142\x65\x66\157\x72\x65\137\151\156\x69\x74", [$this, "\x61\143\141\165\x77\145\161\x79\x79\x75\147\167\151\x73\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\x65\x5f\x62\165\x74\x74\157\156\163", [$this, "\x61\x73\x61\x71\145\x67\x65\x77\165\151\x71\x65\x65\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\x6e\x74\163\151\172\x65\163\145\x6c\x65\x63\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\157\x6e\x74\x73\151\x7a\x65\137\x66\x6f\162\155\x61\x74\x73"] = "\x38\160\170\40\61\x30\160\x78\x20\x31\62\160\170\40\x31\64\x70\x78\40\61\x36\160\170\x20\x32\x30\160\x78\x20\62\x34\160\x78\40\62\x38\x70\x78\x20\63\62\x70\x78\40\x33\x36\160\x78\40\x34\x38\160\x78\x20\x36\60\x70\x78\40\x37\62\x70\170\x20\x39\66\160\170"; return $iwsskoiwswyqeuee; } }
