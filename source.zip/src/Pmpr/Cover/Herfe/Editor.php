<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd83d4717             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\x6e\x79\137\155\143\x65\137\x62\x65\146\x6f\x72\145\137\x69\x6e\x69\164", [$this, "\141\143\x61\165\x77\145\161\x79\x79\165\x67\167\x69\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\x5f\142\165\x74\x74\x6f\156\x73", [$this, "\x61\163\x61\x71\145\x67\x65\x77\165\151\161\145\x65\x63\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\x6e\x74\163\151\x7a\x65\x73\145\154\145\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\156\x74\x73\151\x7a\x65\137\x66\x6f\162\x6d\x61\164\x73"] = "\x38\160\x78\x20\61\60\160\170\x20\x31\x32\x70\170\40\x31\x34\x70\x78\x20\61\66\160\170\40\x32\60\160\170\x20\62\64\x70\170\40\x32\x38\x70\170\x20\63\x32\x70\x78\x20\63\x36\160\170\40\64\x38\x70\x78\x20\66\60\160\170\x20\67\x32\x70\170\x20\71\x36\160\170"; return $iwsskoiwswyqeuee; } }
