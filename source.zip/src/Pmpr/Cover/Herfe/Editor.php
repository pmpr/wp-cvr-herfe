<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f07cbf8e0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\x6e\171\137\155\143\x65\x5f\142\145\x66\157\x72\x65\x5f\151\x6e\151\x74", [$this, "\141\x63\x61\x75\167\145\161\x79\x79\165\147\167\151\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\145\137\x62\x75\164\164\157\156\163", [$this, "\141\163\141\x71\x65\x67\x65\x77\165\151\161\x65\x65\x63\165\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\x6f\x6e\164\x73\151\172\x65\x73\145\x6c\x65\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\x66\x6f\156\x74\163\x69\172\145\x5f\x66\157\x72\155\x61\164\163"] = "\70\x70\170\40\61\x30\160\x78\40\61\62\160\170\40\61\64\160\x78\x20\x31\66\x70\x78\x20\62\60\x70\x78\x20\x32\x34\x70\x78\x20\x32\70\x70\170\x20\x33\62\x70\170\x20\x33\x36\x70\170\x20\64\70\x70\170\x20\x36\60\x70\170\x20\67\62\160\x78\40\71\66\160\x78"; return $iwsskoiwswyqeuee; } }
