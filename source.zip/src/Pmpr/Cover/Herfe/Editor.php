<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716e7d4d9094             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\151\x6e\x79\137\x6d\x63\x65\x5f\142\145\146\x6f\162\x65\137\151\x6e\x69\x74", [$this, "\x61\143\141\165\167\145\161\171\171\165\147\167\151\163\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\x65\x5f\x62\165\164\164\x6f\x6e\x73", [$this, "\x61\x73\141\161\x65\x67\145\167\x75\x69\x71\x65\x65\x63\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\164\x73\x69\172\x65\163\145\x6c\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\164\x73\151\172\145\137\146\157\162\x6d\x61\x74\163"] = "\x38\x70\x78\40\x31\60\x70\x78\40\x31\x32\160\x78\40\61\x34\x70\170\x20\x31\66\160\x78\x20\62\x30\160\170\x20\62\x34\x70\170\x20\62\x38\160\170\x20\x33\x32\x70\x78\x20\63\66\x70\x78\x20\64\70\160\170\40\66\x30\160\x78\40\67\62\160\x78\x20\x39\66\160\170"; return $iwsskoiwswyqeuee; } }
