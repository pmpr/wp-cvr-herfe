<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676e6b5393e5e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x69\x6e\171\137\x6d\143\145\x5f\x62\145\146\x6f\162\145\x5f\x69\x6e\151\164", [$this, "\x61\x63\x61\165\167\145\161\171\171\165\x67\x77\151\x73\161\x63"], PHP_INT_MAX)->cecaguuoecmccuse("\155\x63\x65\137\142\x75\164\x74\157\156\x73", [$this, "\141\163\x61\161\145\147\145\x77\x75\151\161\145\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\157\x6e\164\x73\x69\172\145\x73\145\x6c\145\143\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\x6e\x74\x73\x69\x7a\145\x5f\x66\x6f\x72\x6d\141\x74\163"] = "\x38\160\170\x20\x31\x30\x70\x78\40\x31\62\160\x78\40\61\64\160\170\40\x31\66\x70\170\x20\x32\x30\160\170\40\x32\64\x70\x78\40\x32\x38\x70\170\x20\63\62\160\x78\x20\x33\x36\x70\x78\40\x34\70\160\170\40\66\60\x70\170\x20\67\x32\x70\x78\x20\71\x36\x70\170"; return $iwsskoiwswyqeuee; } }
