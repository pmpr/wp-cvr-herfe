<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce704aa77d2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\151\156\171\x5f\x6d\143\x65\137\x62\145\146\x6f\162\145\137\151\156\151\x74", [$this, "\141\x63\141\x75\167\145\161\x79\171\165\147\x77\151\x73\161\143"], PHP_INT_MAX)->cecaguuoecmccuse("\x6d\143\x65\137\x62\165\x74\164\x6f\x6e\x73", [$this, "\141\163\141\161\145\x67\145\x77\165\151\161\145\145\x63\x75\155"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\146\157\156\164\163\151\172\x65\163\x65\x6c\x65\x63\164"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\157\156\x74\x73\151\x7a\x65\x5f\x66\157\162\x6d\x61\x74\163"] = "\70\x70\170\40\61\x30\160\x78\40\x31\62\160\x78\40\61\64\x70\170\40\x31\66\x70\170\40\x32\x30\160\x78\40\x32\x34\x70\x78\x20\x32\70\160\170\x20\63\62\160\170\x20\x33\x36\x70\x78\x20\64\70\160\x78\x20\66\x30\160\x78\x20\67\x32\x70\170\40\x39\x36\x70\x78"; return $iwsskoiwswyqeuee; } }
