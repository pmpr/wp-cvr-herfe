<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4e90307a77             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe; class Editor extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\x69\x6e\171\137\155\x63\x65\x5f\142\145\x66\157\162\145\x5f\151\156\151\x74", [$this, "\141\x63\x61\x75\167\145\x71\171\x79\x75\147\167\151\x73\x71\143"], PHP_INT_MAX)->cecaguuoecmccuse("\155\143\145\x5f\142\x75\164\x74\157\156\163", [$this, "\x61\163\141\x71\145\147\x65\x77\x75\151\161\x65\145\143\165\x6d"], 999, 2); } public function asaqegewuiqeecum($oammesyieqmwuwyi) { $oammesyieqmwuwyi[] = "\x66\x6f\x6e\x74\163\151\x7a\145\163\x65\x6c\145\143\x74"; return $oammesyieqmwuwyi; } public function acauweqyyugwisqc($iwsskoiwswyqeuee) { $iwsskoiwswyqeuee["\146\x6f\x6e\x74\163\x69\172\145\x5f\x66\x6f\162\155\141\x74\x73"] = "\x38\160\170\40\61\60\x70\x78\x20\61\62\160\170\40\61\64\x70\170\40\61\66\x70\170\40\62\60\160\x78\x20\x32\64\x70\x78\40\62\70\160\x78\x20\x33\x32\x70\170\x20\63\x36\160\170\40\x34\x38\x70\170\40\66\x30\160\170\40\67\62\x70\170\x20\x39\x36\x70\x78"; return $iwsskoiwswyqeuee; } }
