<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646ac739e06d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\x61\x62\x6f\x75\164"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\142\x6f\x75\164", PR__CVR__HERFE); } }
