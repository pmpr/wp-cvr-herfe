<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4e90307a77             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\141\142\157\165\164"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\142\157\165\164", PR__CVR__HERFE); } }
