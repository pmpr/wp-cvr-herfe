<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723571f00508             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\x61\142\x6f\x75\x74"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\142\157\165\x74", PR__CVR__HERFE); } }
