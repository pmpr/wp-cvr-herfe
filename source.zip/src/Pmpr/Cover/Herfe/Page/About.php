<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676e6b5393e5e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\x61\142\x6f\x75\x74"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\x62\157\x75\164", PR__CVR__HERFE); } }
