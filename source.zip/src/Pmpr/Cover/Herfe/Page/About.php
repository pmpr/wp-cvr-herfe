<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d60c76657e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\141\x62\157\x75\164"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\142\157\165\164", PR__CVR__HERFE); } }
