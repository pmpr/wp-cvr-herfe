<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66812ea1dcd5a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\x61\x62\x6f\165\x74"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\x62\x6f\x75\164", PR__CVR__HERFE); } }
