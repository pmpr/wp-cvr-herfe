<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684009332786             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\x61\x62\x6f\165\x74"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x41\142\157\165\164", PR__CVR__HERFE); } }
