<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6888e98d908b5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = 'about'; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __('About', PR__CVR__HERFE); } }
