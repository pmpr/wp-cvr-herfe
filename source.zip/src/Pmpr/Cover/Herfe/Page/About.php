<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114f15b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class About extends AbstractAbout { public function __construct() { $this->slug = "\141\142\157\165\164"; parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\101\x62\x6f\x75\164", PR__CVR__HERFE); } }
