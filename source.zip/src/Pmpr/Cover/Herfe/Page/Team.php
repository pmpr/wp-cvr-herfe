<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce114f15b6d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class Team extends AbstractAbout { public function __construct() { $this->slug = "\x74\x65\x61\155"; $this->parent = About::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\124\145\141\x6d", PR__CVR__HERFE); } }
