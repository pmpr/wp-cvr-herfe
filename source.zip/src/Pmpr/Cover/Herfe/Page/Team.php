<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357a92498e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; class Team extends AbstractAbout { public function __construct() { $this->slug = "\164\145\x61\x6d"; $this->parent = About::symcgieuakksimmu(); parent::__construct(); } public function gogaagekwoisaqgu() { $this->title = __("\x54\x65\141\155", PR__CVR__HERFE); } }
