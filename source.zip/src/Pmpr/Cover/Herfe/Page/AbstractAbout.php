<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a4e90307a77             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; abstract class AbstractAbout extends Common { public function __construct() { $this->isPrivate = false; $this->hasBreadcrumb = true; parent::__construct(); } public function rsysgcucogueguuk() : array { return [self::yusuiaeueqwieqqq => [About::symcgieuakksimmu()->kyqakacqeumicgag(), Team::symcgieuakksimmu()->kyqakacqeumicgag()]]; } }
