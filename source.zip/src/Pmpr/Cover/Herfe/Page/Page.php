<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646ac739e06d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; use Pmpr\Cover\Herfe\Container; class Page extends Container { public function mameiwsayuyquoeq() { Team::symcgieuakksimmu(); About::symcgieuakksimmu(); } }
