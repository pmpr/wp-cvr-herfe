<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f07cbf8e0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; use Pmpr\Cover\Herfe\Container; class Page extends Container { public function mameiwsayuyquoeq() { Team::symcgieuakksimmu(); About::symcgieuakksimmu(); } }
