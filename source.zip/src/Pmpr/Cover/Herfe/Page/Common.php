<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1bfa0a1e1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
