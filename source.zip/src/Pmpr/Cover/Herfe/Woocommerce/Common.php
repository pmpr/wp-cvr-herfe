<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             676e6b5393e5e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Woocommerce; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
