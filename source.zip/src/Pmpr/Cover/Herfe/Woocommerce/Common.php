<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68b43fc5b5782             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Woocommerce; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
