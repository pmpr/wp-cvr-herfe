<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8c90ae16             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Herfe\Woocommerce; use Pmpr\Cover\Herfe\Container; abstract class Common extends Container { }
